package com.example.qrcodes;

public @interface NonNull {
}
