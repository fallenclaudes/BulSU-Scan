package com.example.qrcodes;

public class PrintSummaryReport {


}
